import java.util.ArrayList;
import java.util.List;

public class PowerOfTwoMaxHeap {
    private List<Integer> heap;
    private int branchFactor; // number of children per node = 2^k

    public PowerOfTwoMaxHeap(int k) {
        this.heap = new ArrayList<>();
        this.branchFactor = (int) Math.pow(2, k);
    }

    // Insert a value into the heap
    public void insert(int value) {
        heap.add(value);
        siftUp(heap.size() - 1);
    }

    // Remove and return the max value (root)
    public int popMax() {
        if (heap.isEmpty()) throw new IllegalStateException("Heap is empty!");
        int maxValue = heap.get(0);
        int lastValue = heap.remove(heap.size() - 1);
        if (!heap.isEmpty()) {
            heap.set(0, lastValue);
            siftDown(0);
        }
        return maxValue;
    }

    // Maintain heap property upwards
    private void siftUp(int index) {
        while (index > 0) {
            int parentIndex = (index - 1) / branchFactor;
            if (heap.get(index) > heap.get(parentIndex)) {
                swap(index, parentIndex);
                index = parentIndex;
            } else {
                break;
            }
        }
    }

    // Maintain heap property downwards
    private void siftDown(int index) {
        while (true) {
            int maxIndex = index;
            for (int i = 1; i <= branchFactor; i++) {
                int childIndex = index * branchFactor + i;
                if (childIndex < heap.size() && heap.get(childIndex) > heap.get(maxIndex)) {
                    maxIndex = childIndex;
                }
            }
            if (maxIndex != index) {
                swap(index, maxIndex);
                index = maxIndex;
            } else {
                break;
            }
        }
    }

    private void swap(int i, int j) {
        int temp = heap.get(i);
        heap.set(i, heap.get(j));
        heap.set(j, temp);
    }

    // For debugging
    public void printHeap() {
        System.out.println(heap);
    }

    // Main method to test
    public static void main(String[] args) {
        PowerOfTwoMaxHeap heap = new PowerOfTwoMaxHeap(2); // 2^2 = 4 children per node

        heap.insert(10);
        heap.insert(4);
        heap.insert(30);
        heap.insert(15);
        heap.insert(20);
        heap.insert(50);

        heap.printHeap();

        System.out.println("Popped Max: " + heap.popMax());
        heap.printHeap();
    }
}

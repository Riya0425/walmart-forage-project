Walmart Global Tech – Forage Virtual Experience Project

This folder contains all completed tasks from the Walmart Global Tech Forage Virtual Experience Program.

Task 1: Java implementation of a Power-of-Two Max Heap.
Task 2: UML Class Diagram for a data processing pipeline.
Task 3: ERD design for a normalized relational database.
Task 4: Python script for munging spreadsheet data into SQLite.

Saved for future reference, portfolio use, or posting.